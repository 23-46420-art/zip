# app.py
from flask import Flask, request, jsonify
import mysql.connector
from mysql.connector import Error
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

# DB config - change to match your XAMPP MySQL settings
DB_CONFIG = {
    'host': os.environ.get('DB_HOST', '127.0.0.1'),
    'port': int(os.environ.get('DB_PORT', 3306)),
    'user': os.environ.get('DB_USER', 'root'),
    'password': os.environ.get('DB_PASSWORD', ''),  # XAMPP default often empty
    'database': os.environ.get('DB_NAME', 'starkbites')
}

def get_conn():
    return mysql.connector.connect(**DB_CONFIG)

# --- Menu endpoints ---
@app.route('/api/menu', methods=['GET'])
def list_menu():
    try:
        conn = get_conn()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, name, description, price, available FROM menu_items WHERE available=1")
        items = cursor.fetchall()
        return jsonify({'menu': items})
    finally:
        cursor.close()
        conn.close()

# Admin create/update/delete menu item (simple, no auth)
@app.route('/api/admin/menu', methods=['POST'])
def create_menu_item():
    data = request.json
    try:
        conn = get_conn()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO menu_items (name, description, price, available) VALUES (%s,%s,%s,%s)",
            (data.get('name'), data.get('description'), data.get('price'), int(data.get('available',1)))
        )
        conn.commit()
        return jsonify({'ok': True, 'id': cursor.lastrowid}), 201
    finally:
        cursor.close()
        conn.close()

@app.route('/api/admin/menu/<int:item_id>', methods=['PUT','DELETE'])
def modify_menu_item(item_id):
    try:
        conn = get_conn()
        cursor = conn.cursor()
        if request.method == 'PUT':
            data = request.json
            cursor.execute(
                "UPDATE menu_items SET name=%s, description=%s, price=%s, available=%s WHERE id=%s",
                (data.get('name'), data.get('description'), data.get('price'), int(data.get('available',1)), item_id)
            )
            conn.commit()
            return jsonify({'ok': True})
        else:
            cursor.execute("DELETE FROM menu_items WHERE id=%s", (item_id,))
            conn.commit()
            return jsonify({'ok': True})
    finally:
        cursor.close()
        conn.close()

# --- Orders ---
@app.route('/api/orders', methods=['POST'])
def place_order():
    payload = request.json
    customer_name = payload.get('customer_name')
    customer_email = payload.get('customer_email')
    items = payload.get('items', [])  # list of {"menu_item_id":1, "qty":2}

    if not customer_name or not items:
        return jsonify({'error': 'missing customer_name or items'}), 400

    try:
        conn = get_conn()
        cursor = conn.cursor()
        # compute total and insert order
        total = 0
        # fetch prices
        item_ids = [it['menu_item_id'] for it in items]
        format_ids = ",".join(["%s"] * len(item_ids))
        cursor.execute(f"SELECT id, price FROM menu_items WHERE id IN ({format_ids})", tuple(item_ids))
        price_map = {row[0]: float(row[1]) for row in cursor.fetchall()}
        for it in items:
            price = price_map.get(it['menu_item_id'], 0)
            total += price * int(it.get('qty',1))
        cursor.execute("INSERT INTO orders (customer_name, customer_email, total) VALUES (%s,%s,%s)",
                       (customer_name, customer_email, total))
        order_id = cursor.lastrowid
        # insert order_items
        for it in items:
            item_id = it['menu_item_id']
            qty = int(it.get('qty',1))
            price = price_map.get(item_id, 0)
            cursor.execute("INSERT INTO order_items (order_id, menu_item_id, qty, price) VALUES (%s,%s,%s,%s)",
                           (order_id, item_id, qty, price))
        conn.commit()
        # For demo, "simulate" payment step not integrated with gateway
        return jsonify({'ok': True, 'order_id': order_id, 'total': total}), 201
    finally:
        cursor.close()
        conn.close()

@app.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    try:
        conn = get_conn()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, customer_name, customer_email, total, status, created_at FROM orders WHERE id=%s", (order_id,))
        order = cursor.fetchone()
        if not order:
            return jsonify({'error':'not found'}), 404
        cursor.execute("SELECT oi.qty, oi.price, mi.name FROM order_items oi JOIN menu_items mi ON oi.menu_item_id=mi.id WHERE oi.order_id=%s", (order_id,))
        items = cursor.fetchall()
        order['items'] = items
        return jsonify({'order': order})
    finally:
        cursor.close()
        conn.close()

# Staff: update order status
@app.route('/api/orders/<int:order_id>/status', methods=['PUT'])
def update_status(order_id):
    payload = request.json
    new_status = payload.get('status')
    if new_status not in ('placed','preparing','ready','completed','cancelled'):
        return jsonify({'error':'invalid status'}), 400
    try:
        conn = get_conn()
        cursor = conn.cursor()
        cursor.execute("UPDATE orders SET status=%s WHERE id=%s", (new_status, order_id))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        cursor.close()
        conn.close()

# Basic orders listing for staff
@app.route('/api/staff/orders', methods=['GET'])
def staff_orders():
    try:
        conn = get_conn()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, customer_name, total, status, created_at FROM orders ORDER BY created_at DESC LIMIT 50")
        rows = cursor.fetchall()
        return jsonify({'orders': rows})
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    app.run(debug=True, port=5000)
