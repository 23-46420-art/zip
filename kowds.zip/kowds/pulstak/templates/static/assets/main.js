const API = 'http://127.0.0.1:5000/api';

let menu = [];
let cart = [];

async function fetchMenu() {
  const res = await fetch(API + '/menu');
  const data = await res.json();
  menu = data.menu || [];
  renderMenu();
}

function renderMenu() {
  const el = document.getElementById('menu-list');
  el.innerHTML = '';
  menu.forEach(item => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<h3>${item.name}</h3>
      <p>${item.description || ''}</p>
      <strong>₱${Number(item.price).toFixed(2)}</strong>
      <div class="row"><input type="number" min="1" value="1" id="qty-${item.id}" style="width:70px" />
      <button data-id="${item.id}">Add</button></div>`;
    el.appendChild(card);
  });

  // attach buttons
  document.querySelectorAll('#menu-list button').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = Number(e.currentTarget.dataset.id);
      const qty = Number(document.getElementById('qty-' + id).value) || 1;
      addToCart(id, qty);
    });
  });
}

function addToCart(menuItemId, qty) {
  const existing = cart.find(c => c.menu_item_id === menuItemId);
  if (existing) existing.qty += qty;
  else cart.push({ menu_item_id: menuItemId, qty });
  renderCart();
}

function renderCart() {
  const el = document.getElementById('cart-items');
  if (!cart.length) { el.innerHTML = '<em>No items</em>'; return; }
  el.innerHTML = cart.map(c => {
    const m = menu.find(x => x.id === c.menu_item_id);
    return `<div>${m.name} x ${c.qty} — ₱${(m.price * c.qty).toFixed(2)}</div>`;
  }).join('');
}

document.getElementById('place-order-btn').addEventListener('click', async () => {
  const name = document.getElementById('customer_name').value.trim();
  const email = document.getElementById('customer_email').value.trim();
  if (!name) { alert('Enter your name'); return; }
  if (!cart.length) { alert('Cart is empty'); return; }

  const res = await fetch(API + '/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ customer_name: name, customer_email: email, items: cart })
  });
  const data = await res.json();
  if (res.ok) {
    document.getElementById('order-msg').textContent = `Order placed. Order ID: ${data.order_id} — Total ₱${Number(data.total).toFixed(2)}`;
    cart = [];
    renderCart();
  } else {
    document.getElementById('order-msg').textContent = data.error || 'Error placing order';
  }
});

document.getElementById('track-btn').addEventListener('click', async () => {
  const id = document.getElementById('track-id').value.trim();
  if (!id) return alert('Enter order ID');
  const res = await fetch(API + '/orders/' + id);
  const data = await res.json();
  if (res.ok) {
    document.getElementById('track-result').textContent = JSON.stringify(data.order, null, 2);
  } else {
    document.getElementById('track-result').textContent = data.error || 'Not found';
  }
});

// staff listing & update
async function fetchStaffOrders() {
  const res = await fetch(API + '/staff/orders');
  const data = await res.json();
  const el = document.getElementById('staff-orders');
  el.innerHTML = data.orders.map(o => {
    return `<div class="order">
      <strong>Order ${o.id}</strong> - ${o.customer_name} - ₱${Number(o.total).toFixed(2)} <br/>
      <small>${o.status} • ${o.created_at}</small>
      <div class="row">
        <select data-id="${o.id}" id="status-${o.id}">
          <option value="placed">placed</option><option value="preparing">preparing</option>
          <option value="ready">ready</option><option value="completed">completed</option><option value="cancelled">cancelled</option>
        </select>
        <button data-id="${o.id}" class="update-btn">Update</button>
      </div>
    </div>`;
  }).join('');
  document.querySelectorAll('.update-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.currentTarget.dataset.id;
      const status = document.getElementById('status-' + id).value;
      await fetch(API + '/orders/' + id + '/status', {
        method: 'PUT', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({status})
      });
      fetchStaffOrders();
    });
  });
}

document.getElementById('refresh-staff').addEventListener('click', fetchStaffOrders);

// init
fetchMenu();
fetchStaffOrders();
renderCart();
