-- Create database
CREATE DATABASE IF NOT EXISTS starkbites;
USE starkbites;

-- 🔹 Table: menu_items
CREATE TABLE menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category ENUM('Appetizer','Main Course','Dessert','Drink') DEFAULT 'Main Course',
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    available BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 🔹 Table: orders
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(120),
    total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('placed','preparing','ready','completed','cancelled') DEFAULT 'placed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 🔹 Table: order_items
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    menu_item_id INT NOT NULL,
    qty INT NOT NULL CHECK (qty > 0),
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
);

-- 🔹 Table: users (optional for admin/staff management)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','staff','customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 🔹 Insert sample menu data
INSERT INTO menu_items (name, description, category, price, available) VALUES
('Arc Reactor Burger', 'Juicy beef burger powered by Stark tech.', 'Main Course', 199.99, 1),
('Vibranium Fries', 'Crispy golden fries with energy seasoning.', 'Appetizer', 89.99, 1),
('Infinity Smoothie', 'A colorful fruit blend inspired by the stones.', 'Drink', 129.50, 1),
('Jarvis Sundae', 'AI-assisted dessert with smart toppings.', 'Dessert', 149.00, 1);

-- 🔹 Optional: default admin user (password hashing handled by Flask)
INSERT INTO users (username, password_hash, role)
VALUES ('admin', 'admin123', 'admin');
